#pragma once

namespace BWDI
{
  namespace RaceIDs
  {
    enum Enum
    {
      Zerg,
      Terran,
      Protoss,
      None,
      count
    };
  }
  typedef RaceIDs::Enum RaceID;
}
