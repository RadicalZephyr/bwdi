#pragma once

#include <Util\Types.h>

namespace BWDI
{
  typedef s32 PlayerID;
  static const PlayerID INVALID_PLAYER = -1;
}
