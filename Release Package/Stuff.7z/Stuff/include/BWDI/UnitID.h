#pragma once

#include <Util\Types.h>

namespace BWDI
{
  typedef s32 UnitID;
  static const UnitID INVALID_UNIT = -1;
}
