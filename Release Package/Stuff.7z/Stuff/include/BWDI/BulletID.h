#pragma once

#include <Util\Types.h>

namespace BWDI
{
  typedef s32 BulletID;
  static const BulletID INVALID_BULLET = -1;
}
