#include "WalkPosition.h"
#include "Position.h"
#include "BuildPosition.h"

namespace BWDI
{
  /*
  WalkPosition WalkPosition::Invalid(Util::Point<int>::Invalid);
  //----------------------------- CONSTRUCTOR ----------------------------------
  WalkPosition::WalkPosition()
    : Point()
  {
  }
  //----------------------------- CONSTRUCTOR ----------------------------------
  WalkPosition::WalkPosition(int x, int y)
    : Point(x, y)
  {
  }
  //------------------------------ CONVERSION ----------------------------------
  Position WalkPosition::toPixels()
  {
    return Position(x*8, y*8);
  }
  //------------------------------ CONVERSION ----------------------------------
  BuildPosition WalkPosition::toBuildTiles()
  {
    return BuildPosition(x/4, y/4);
  }
  //------------------------------ ---------------------------------------------
  */
};
