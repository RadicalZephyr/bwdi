#pragma once

#include <Util\StaticString.h>

namespace BWDI
{
  struct DamageType
  {
    Util::StaticString<32> name;
  };
}
