#pragma once

#include "PlayerID.h"

#include <Util\StaticString.h>
#include <Util\StaticVector.h>

namespace BWDI
{
  struct Force
  {
    Util::StaticString<32> name;
  };
}
