#pragma once

namespace BWDI
{
  static const int PixelsPerBuildTile = 32;
  static const int PixelsPerWalkTile = 8;
  static const int WalkPerBuildTile = 4;
}
