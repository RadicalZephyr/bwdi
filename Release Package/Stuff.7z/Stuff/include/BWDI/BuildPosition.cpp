#include "Position.h"
#include "WalkPosition.h"
#include "BuildPosition.h"

namespace BWDI
{
  /*
  BuildPosition BuildPosition::Invalid(Util::Point<int>::Invalid);
  //----------------------------- CONSTRUCTOR ----------------------------------
  BuildPosition::BuildPosition()
    : Point()
  {
  }
  //----------------------------- CONSTRUCTOR ----------------------------------
  BuildPosition::BuildPosition(int x, int y)
    : Point(x, y)
  {
  }
  //------------------------------ CONVERSION ----------------------------------
  Position BuildPosition::toPixels()
  {
    return Position(x*32, y*32);
  }
  //------------------------------ CONVERSION ----------------------------------
  WalkPosition BuildPosition::toWalkTiles()
  {
    return BuildPosition(x*4, y*4);
  }
  //------------------------------ ---------------------------------------------
  */
};
