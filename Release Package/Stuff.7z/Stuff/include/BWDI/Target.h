#pragma once

#include "UnitID.h"
#include "Position.h"

namespace BWDI
{
  struct Target
  {
    UnitID unit;
    Position position;
  };
}
