#pragma once

#include <Util\Types.h>

namespace BWDI
{
  typedef s32 ForceID;
  static const ForceID INVALID_FORCE = -1;
}
