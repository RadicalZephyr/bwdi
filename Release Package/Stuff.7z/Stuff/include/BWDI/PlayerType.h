#pragma once

#include <Util\StaticString.h>

namespace BWDI
{
  struct PlayerType
  {
    Util::StaticString<32> name;
  };
}
