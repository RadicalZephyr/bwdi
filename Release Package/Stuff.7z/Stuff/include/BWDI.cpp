#include "BWDI\BuildPosition.cpp"
#include "BWDI\Position.cpp"
#include "BWDI\WalkPosition.cpp"
